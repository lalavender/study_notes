#!/usr/bin/env python
# -*- coding:utf-8 -*-
from to_asm import to_asm
import os

path = os.getcwd()
filename = path + "/test.c"


def main():
    try:
        to_asm(filename)
        os.system("gcc " + filename[:-1] + "s -o " + filename[:-2])
        print("编译成功，执行：" + filename[:-2])
    except:
        print("编译失败！！！", end="")


if __name__ == '__main__':
    main()
