# 环境：python3.6
# 编译原理——词法分析器
# 刘金明——320160939811
import re

# 运算符表
y_list = {"+","-","*","/","<","<=",">",">=","=","==","!=","^",",","&","&&","|","||","%","~","<<",">>","!"}
# 分隔符表
f_list = {";","(",")","[","]","{","}", ".",":","\"","#","\'","\\","?"}
# 关键字表
k_list = {
    "auto", "break", "case", "char", "const", "continue","default", "do", "double", "else", "enum", "extern",
    "float", "for", "goto", "if", "int", "long","register", "return", "short", "signed", "sizeof", "static",
    "struct", "switch", "typedef", "union", "unsigned", "void","volatile", "while", "printf"
}

Cmp = ["<", ">", "==", "!=", "<=", ">="]

# 正则表达式判断是否为数字
def if_num(int_word):
    if re.match("^([0-9]{1,}[.][0-9]*)$",int_word) or re.match("^([0-9]{1,})$",int_word) == None:
        return False
    else:
        return True

# 判断是否为为变量名
def if_name(int_word):
    if re.match("[a-zA-Z_][a-zA-Z0-9_]*",int_word) == None:
        return False
    else:
        return True

# 判断变量名是否已存在
def have_name(name_list,name):
    for n in name_list:
        if name == n['name']:
            return True
    return False

# list的换行输出
def printf(lists):
    for l in lists:
        print(l)